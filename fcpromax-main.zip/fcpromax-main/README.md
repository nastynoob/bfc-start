
<img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/azimvau.gif" width="120" height="120" align="left">
<center>
  
  
  
   ## * MY SOCIAL MEDIA : <br>
<a href="https://Instagram.com/azimmahmud143" target="_blank"><img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/instagram.png" alt="alt text" width="25" height="25"></a> 
<a href="https://t.me/mrerror69"><img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/telegram.png" alt="alt text" width="25" height="25"></a>
<a href="https://www.facebook.com/azimmahmudofficial" target="_blank"><img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/facebook.png" alt="alt text" width="25" height="25"></a> <a href="https://youtube.com/MrError69"><img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/youtube.png" alt="alt text" width="25" height="25"></a> 
&nbsp;&nbsp;     &nbsp;&nbsp;    &nbsp;&nbsp;   &nbsp;&nbsp;   &nbsp;&nbsp;
  
____Programming And Memes____

Want to contact <a href="https://github.com/Azim-vau"><b>Mr. Error </a> ?</br><br>
<img src="https://github.com/Azim-vau/Azim-vau/blob/main/IMAGE/contact.png" alt="alt text" width="25" height="25"> <br>
CONTACT : <i>errorazim@gmail.com</i>  <br> <br> 


<a href="https://github.com/Azim-Vau/followers">
<img title="Followers" src="https://img.shields.io/github/followers/Azim-vau?label=Followers&color=blue&style=flat-square"></a>
<a href="https://github.com/Azim-Vau/termux-style/stargazers/">
  <a href="https://github.com/Azim-Vau/fcpromax">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/Azim-Vau/fcpromax.svg"/>
  </a>
  <a href="https://github.com/Azim-Vau/fcpromax">
    <img alt="Language" src="https://img.shields.io/github/languages/count/Azim-Vau/fcpromax.svg"/>
  </a>
  <a href="https://github.com/Azim-Vau/fcpromax">
    <img alt="Starts" src="https://img.shields.io/github/stars/Azim-Vau/fcpromax.svg"/>
  </a>
<a href="https://github.com/Azim-Vau/fcpromax">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/Azim-Vau/fcpromax.svg"/>
  </a>

<a href="https://github.com/Azim-Vau/fcpromax">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/Azim-vau/fcpromax.svg"/> <a href="https://github.com/Azim-Vau/fcpromax">
    <img alt="Forks" src="https://img.shields.io/github/forks/Azim-vau/fcpromax.svg"/>
  </a>
</div>

<p align="center">

#### INSTALL TOOL ON TERMUX
```python
$ apt update && apt upgrade
$ apt install python
$ pip install lolcat
$ pip install mechanize
$ pip install requests bs4
$ apt install git
$ git clone https://github.com/Azim-Vau/fcpromax.git
```
#### RUN SCRIPT
```python
$ cd fcpromax
$ python fcpromax.py
```

#### [~] SINGLE COMMAND

```python
apt update -y ; apt upgrade -y ; apt install python -y ; pip install requests ; pip install mechanize ; pip install lolcat ; pip install bs4 ; apt install git -y ; git clone https://github.com/Azim-vau/fcpromax ; cd fcpromax ; python fcpromax.py
```
<b>DOWNLOAD ACCESS TOKEN APK</b><br>
 <a href="https://play.google.com/store/apps/details?id=com.proit.thaison.getaccesstokenfacebook">  DOWNLOAD</a>
</br>
#### MY SOCIAL MEDIA

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/Azim-Vau)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/azimmahmudofficial)
[![](https://img.shields.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)](https://www.instagram.com/azimmahmud143) 



#### THANKS FOR USING MY SCRIPT
